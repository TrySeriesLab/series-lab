export default async function handler(req, res) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // CORS headers — allows your frontend to talk to this backend
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  try {
    const { model, max_tokens, system, messages } = req.body;

    // Validate the request has what we need
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Invalid request — messages required' });
    }

    // Call Anthropic API using the secret key stored in Vercel environment
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY, // Secret — never exposed to users
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: model || 'claude-sonnet-4-20250514',
        max_tokens: max_tokens || 4000,
        system: system || '',
        messages,
      }),
    });

    const data = await response.json();

    // If Anthropic returned an error, pass it through
    if (data.error) {
      return res.status(400).json({ error: data.error.message });
    }

    // Send the response back to the frontend
    return res.status(200).json(data);

  } catch (error) {
    console.error('API Error:', error);
    return res.status(500).json({ error: 'Server error — please try again' });
  }
}
